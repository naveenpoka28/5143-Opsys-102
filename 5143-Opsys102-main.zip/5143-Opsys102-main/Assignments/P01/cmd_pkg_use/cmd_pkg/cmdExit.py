import sys

def exit(**kwargs):
    sys.exit()